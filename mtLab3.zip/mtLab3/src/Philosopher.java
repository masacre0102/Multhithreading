import java.util.concurrent.locks.Lock;

class Philosopher extends Thread {
    private Lock leftFork;
    private Lock rightFork;

    public Philosopher(String name, Lock leftFork, Lock rightFork) {
        super(name);
        this.leftFork = leftFork;
        this.rightFork = rightFork;
    }

    @Override
    public void run() {
        while (true) {
            think();
            eat();
        }
    }

    private void think() {
        System.out.println(getName() + " is thinking");
        try {
            Thread.sleep(1000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    private void eat() {
        leftFork.lock();
        rightFork.lock();

        try {
            System.out.println(getName() + " is eating");
            try {
                Thread.sleep(1000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        } finally {
            rightFork.unlock();
            leftFork.unlock();
        }
    }
}
