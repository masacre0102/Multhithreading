import java.util.Collections;
import java.util.HashSet;
import java.util.Objects;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import static java.util.stream.Collectors.joining;

public class ThreadExample {
    private static volatile int x;
    private static volatile int y;
    private static volatile int z;
    private static final Set xValues = Collections.synchronizedSet(new HashSet<>());

    public static void main(String[] args) throws InterruptedException {
        ExecutorService executor = Executors.newFixedThreadPool(4);

        // Thread 1
        executor.submit(() -> {
            x = 0;
            y = 0;
            z = 0;
            while (true) {
                x = 1;
                x = 2;
                x = z;
                xValues.add(x);
            }
        });

        // Thread 2
        executor.submit(() -> {
            x = 1;
            y = 1;
            z = 1;
            while (true) {
                y = x;
                y = 3;
                z = 1;
                xValues.add(x);
            }
        });

        // Thread 3
        executor.submit(() -> {
            x = 2;
            y = 2;
            z = 2;
            while (true) {
                z = 2;
                z = y;
                x = 1;
                xValues.add(x);
            }
        });

        // Thread 4
        executor.submit(() -> {
            x = 0;
            y = 1;
            z = 2;
            while (true) {
                y = 3;
                y = 5;
                x = 7;
                xValues.add(x);
            }
        });

        Thread.sleep(1000);

        executor.shutdownNow();

        // /^(0|1|2|3|5|7)+$

        System.out.println("Observed x values: " + xValues);
    }
}
