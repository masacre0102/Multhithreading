import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

public class DataExchange {
    private static final Lock lockA = new ReentrantLock();
    private static final Lock lockB = new ReentrantLock();

    private static int a = 0;
    private static int b = 0;

    public static void main(String[] args) {
        Thread threadA = new Thread(() -> {
            try {
                exchangeDataA();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        });

        Thread threadB = new Thread(() -> {
            try {
                exchangeDataB();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        });

        threadA.start();
        threadB.start();

        try {
            threadA.join();
            threadB.join();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        System.out.println("Final values: a = " + a + ", b = " + b);
    }

    private static void exchangeDataA() throws InterruptedException {
        lockA.lock();
        System.out.println("Thread A locked for a");

        // моделюємо деякі обчислення з локальними даними "a"
        Thread.sleep(1000);
        a = 5;

        System.out.println("Thread A updated a");

        lockB.lock();
        System.out.println("Thread A locked for b");

        // використовуємо дані для локальної змінної "b" та виконуємо обчислення
        int result = b * 2;
        System.out.println("Thread A computed result using b: " + result);

        lockB.unlock();
        System.out.println("Thread A unlocked b");

        lockA.unlock();
        System.out.println("Thread A unlocked a");
    }

    private static void exchangeDataB() throws InterruptedException {
        lockB.lock();
        System.out.println("Thread B locked for b");

        // моделюємо деякі обчислення з локальними даними "b"
        Thread.sleep(1000);
        b = 10;

        System.out.println("Thread B updated b");

        lockA.lock();
        System.out.println("Thread B locked for a");

        // використовуємо дані для локальної змінної "а" та виконуємо обчислення
        int result = a + 3;
        System.out.println("Thread B computed result using a: " + result);

        lockA.unlock();
        System.out.println("Thread B unlocked a");

        lockB.unlock();
        System.out.println("Thread B unlocked b");
    }
}
